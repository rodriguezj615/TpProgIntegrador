<?php
function credenciales() {
    return [
        'usuario'=>'juan' ,
        'clave'=>'supersecreto',
        'servidor'=>'localhost',
        'base_de_datos'=>'banco'
    ];
}
